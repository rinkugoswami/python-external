#!/usr/bin/python

from HTMLParser import HTMLParser

class HTMLCleaner(HTMLParser):

	container = ""

	def handle_data(self, data):
		self.container += data
		return self.container

h = HTMLCleaner()

h.feed(" <p> this is a <b> small</b> program with some <i>HTML</i> tag inside. </p>")

print h.container
