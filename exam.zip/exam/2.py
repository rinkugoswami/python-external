#!/usr/bin/python

import re

f = open('amazon.txt','r')

strings = re.findall(r'\w+.amazon.com', f.read())

distinct_list = []
for each in strings:
	if each not in distinct_list:
		distinct_list.append(each)
for str in distinct_list:
	print str
